package pokemondigimon;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Pokemon versus Digimon fight
 * @author Jose
 */
public class PokeMonVersusDigimon {

    public static void main(String[] args) {
        PokeMonVersusDigimon p = new PokeMonVersusDigimon();
        p.run();
    }

    private void run() {
        //read and instantiate fighters
        Pokemon pokemon = readPokemon();
        Digimon digimon = readDigimon();
        //fight
        boolean digimonAlive = true;  //digimon is alive flag
        boolean pokemonAlive = true;  //pokemon is alive flag
        do {
            int force;
            //pokemon attack
            force = pokemon.attack();
            digimonAlive = digimon.receiveAttack(force);
            if (digimonAlive) {
                //digimon attack
                force = digimon.attack();
                pokemonAlive = pokemon.receiveAttack(force);
            }
            //report state
            System.out.format("Pokemon> name:%s, lifePoints:%d\n", pokemon.getName(), pokemon.getLifePoints());
            System.out.format("Digimon> name:%s, lifePoints:%d\n", digimon.getName(), digimon.getLifePoints());
        } while (pokemonAlive && digimonAlive);
        //report result
        String winner = (pokemonAlive) ? "pokemon" : "digimon";
        System.out.format("%s wins!\n", winner);
    }

    /**
     * creates a Pokemon, reads data from user and validate them
     * @return 
     */
    private Pokemon readPokemon() {
        Scanner sc = new Scanner(System.in);
        //read name
        System.out.print("Pokemon's name: ");
        String name = sc.nextLine();
        //read lifePoints
        boolean dataValid = false;
        int lifePoints = 0;
        do {
            System.out.print("Pokemon's lifePoints: ");
            try {
                lifePoints = sc.nextInt();
                dataValid = true;
            } catch (InputMismatchException e) {
                System.out.println("Not numeric data");
                sc.next();
            }
        } while (!dataValid);
        return new Pokemon(name, lifePoints);
    }

    /**
     * creates a Digimon, reas data from user
     * @return 
     */
    private Digimon readDigimon() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Digimon's name: ");
        String nom = sc.nextLine();
        return new Digimon(nom);
    }

}
