package prgmod;

import java.util.Scanner;

/**
 *
 * @author ProvenSoft
 */
public class Ex08SumaProd {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int num1; //TODO
        int num2;
        //si ordre invertit, intercanviar valors de variables
        if (num1 > num2) {
            int aux = num2;
            num2 = num1;
            num1 = aux;
        }
    }
    
}
