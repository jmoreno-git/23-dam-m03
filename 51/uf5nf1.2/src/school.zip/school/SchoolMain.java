package school;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ProvenSoft
 */
public class SchoolMain {
    
    private List<Group> groups;

    public SchoolMain() {
        this.groups = new ArrayList<>();
        generateGroups();
    }

    public static void main(String[] args) {
        SchoolMain sm = new SchoolMain();
        sm.init();
    }

    private void init() {
        groups.sort(null);
        System.out.println("Groups: "+groups);
        List<Student> dam1List = getStudentsByGroupName("DAM1");
        dam1List.sort(null);
        System.out.println("Students in DAM1: "+dam1List);
        //
        List<Student> dam1ListSorted1 = groups.get(0).getStudentsSortedByMeanMark();
        System.out.println("Students in DAM1 sorted by mean mark");
        System.out.println(dam1ListSorted1);
        for (Student st : dam1ListSorted1) {
            System.out.printf("%s %s: %f%n", 
                    st.getName(), st.getSurname(), st.getMeanMark());
        }
        //
        List<Student> dam1ListSorted2 = groups.get(0).getStudentsSortedByMaxMark();
        System.out.println("Students in DAM1 sorted by max mark");
        System.out.println(dam1ListSorted1);
        for (Student st : dam1ListSorted2) {
            System.out.printf("%s %s: %d%n", 
                    st.getName(), st.getSurname(), st.getMaxMark());
        }
    }

    private void generateGroups() {
        Group g;
        Student s;
        //
        g = new Group("DAW1");
        groups.add(g);
        //
        g = new Group("DAM1");
            //
            s = new Student("Joseph", "Morgan");
                s.getMarks().add(5);
                s.getMarks().add(6);
                s.getMarks().add(3);
                s.getMarks().add(8);
                s.getMarks().add(1);
            g.getStudents().add(s );
            //
            s = new Student("Albert", "Morgan");
                s.getMarks().add(9);
                s.getMarks().add(7);
                s.getMarks().add(8);
                s.getMarks().add(10);
                s.getMarks().add(7);
            g.getStudents().add( s );
            //
            s = new Student("Zoe", "Lopez");
                s.getMarks().add(2);
                s.getMarks().add(5);
                s.getMarks().add(6);
                s.getMarks().add(9);
                s.getMarks().add(3);
            g.getStudents().add( s );
        //
        groups.add(g);

    }
    
    public List<Student> getStudentsByGroupName(String grName) {
        List<Student> list = null;
        for (Group g : groups) {
            if (g.getName().equals(grName)) {
                //list = g.getStudents();
                list = new ArrayList<>(g.getStudents());
            }
        }
        return list;
    }
}
