package school;

import java.util.Comparator;

/**
 *
 * @author ProvenSoft
 */
public class StudentComparatorByMaxMark implements Comparator<Student> {

    @Override
    public int compare(Student o1, Student o2) {
        return o1.getMaxMark() - o2.getMaxMark();
    }
    
}
