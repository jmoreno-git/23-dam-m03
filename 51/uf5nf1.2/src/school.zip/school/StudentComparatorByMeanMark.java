package school;

import java.util.Comparator;

/**
 *
 * @author ProvenSoft
 */
public class StudentComparatorByMeanMark implements Comparator<Student> {

    @Override
    public int compare(Student o1, Student o2) {
        return (int) Math.round(o1.getMeanMark() - o2.getMeanMark());
    }
    
}
