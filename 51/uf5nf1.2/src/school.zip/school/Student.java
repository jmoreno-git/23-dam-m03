package school;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author provenSoft
 */
public class Student implements Comparable {
    
    private String name;
    private String surname;
    private List<Integer> marks;

    public Student(String name, String surname) {
        this.name = name;
        this.surname = surname;
        this.marks = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public List<Integer> getMarks() {
        return marks;
    }

    public void setMarks(List<Integer> marks) {
        this.marks = marks;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + Objects.hashCode(this.name);
        hash = 37 * hash + Objects.hashCode(this.surname);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Student other = (Student) obj;
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        return Objects.equals(this.surname, other.surname);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Student{");
        sb.append("name=").append(name);
        sb.append(", surname=").append(surname);
        sb.append(", marks=").append(marks);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public int compareTo(Object o) {
        int result = 0;
        Student other = (Student) o;
        result = this.surname.compareTo(other.surname);
        if (result == 0) {  //surname equals
            result = this.name.compareTo(other.name);
        }
        return result;
    }
    
    public double getMeanMark() {
        double mean = 0.0;
        if (!marks.isEmpty()) {
            for (Integer mark : marks) {
               mean += mark;
            }
        mean /= marks.size();           
        }
        return mean;
    }
    
    public int getMaxMark() {
        int max = 0;
        if (!marks.isEmpty()) {
            max = marks.get(0);
            for (int i = 1; i < marks.size(); i++) {
                max = Math.max(max, marks.get(i));
            }
        }
        return max;
    }    
}
