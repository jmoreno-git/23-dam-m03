package store;

import java.util.List;
import java.util.Scanner;

/**
 *
 * @author ProvenSoft
 */
public class StoreMain {

    private Store myStore;
    private boolean exit;  //flag to exit application.
    private Scanner scan;
    
    public StoreMain() {
        myStore = new Store("La meva botigueta");
        scan = new Scanner(System.in);
    }
    
    public static void main(String[] args) {
        StoreMain sm = new StoreMain();
        sm.run();
    }

    private void run() {
        //instantiate store
        //myStore = new Store("La meva botigueta");
        myStore.generateProducts();
        //
        exit = false;
        //instantiate menu
        Menu mnu = createMenu();
        //control loop (interact with user)
        do {            
            //display menu and read user's choice
            int option = mnu.displayMenuAndReadOption();
            switch (option) {
                case 0: //exit
                    doExit();
                    break;
                case 1: //list all products
                    doListAllProducts();
                    break;
                case 2: //list product by code
                    doListProductByCode();
                    break;
                case 3: //list products with low stock
                    break;
                case 4: //add a new product
                    doAddProduct();
                    break;
                case 5: //modify a product
                    break;
                case 6: //remove a product
                    break;
                default:
                    System.out.println("Invalid option");
                    break;
            }
        } while (!exit);
    }

    private Menu createMenu() {
        Menu mnu = new Menu("Store application");
        mnu.addOption("Exit");
        mnu.addOption("List all products");
        mnu.addOption("List product by code");
        mnu.addOption("List products with low stock");
        mnu.addOption("Add a new product");
        mnu.addOption("Modify a product");
        mnu.addOption("Remove a product");
        return mnu;
    }

    /**
     * asks for confirmation and exits application
     */
    private void doExit() {
        //TODO: ask confirmation
        exit = true;
    }

    /**
     * lists all products
     */
    private void doListAllProducts() {
        List<Product> result = myStore.getAllProducts();
        displayProductList(result);
    }
    
    /**
     * displays the list of products
     * @param data the list to display
     */
    private void displayProductList(List<Product> data) {
        for (Product p : data) {
            System.out.println(p);
        }
        System.out.format("%d elements shown%n", data.size());
    }

    /**
     * reads from user the code of the product,
     * then searches the product with that code,
     * if found, it displays the product,
     * if not found, it reports to user.
     */
    private void doListProductByCode() {
        //read the code
        System.out.print("Input the code: ");
        String code = scan.next();
        //
        Product result = myStore.getProductByCode(code);
        if (result != null) {  //found
            System.out.println(result);
        } else {  //not found
            System.out.printf("Product with code '%s' not found%n", code);
        }
    }

    /**
     * reads from user data for the new product,
     * if correctly read instantiates a product with that data,
     * and adds the product to the list
     * If not correctly read, it reports the error to the user
     * Finally, it reports result to user.
     */
    private void doAddProduct() {
        //read the product
        Product prod = readProduct();
        if (prod != null) {  //correctly read
            boolean result = myStore.addProduct(prod);
            if (result) { //added
                System.out.println("Product successfully added");
            } else {  //not added
                System.out.println("Product not added");
            }
        } else {  //invalid data read
            System.out.println("Invalid data!");
        }
    }
    
    /**
     * reads from user a product
     * @return the product read or null in case of error
     */
    private Product readProduct() {
        Product p = null;
        //TODO
        return p;
    }
}
